include<iostream>
using namespace std;

class student{
   int roll_no;
   string name;
   public:
      student(int r, string n)
      {
      roll_no = r;
      name = n;
      }
    void print()
    {
        cout<<"Roll No is : "<<roll_no<<endl;
        cout<<"Name is : "<<name<<endl;
     }
};

int main()
{
student obj(101, "Mohan");
obj.print();
return 0;
}