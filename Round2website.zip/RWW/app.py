from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# MySQL Database Configuration
db_config = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': ' ',
    'database': 'schema',
    'auth_plugin': 'mysql_native_password'
}

# Establish MySQL connection
db = mysql.connector.connect(**db_config)
cursor = db.cursor()

# Flask Route for Login
@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check credentials in the database
        query = "SELECT * FROM users WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        user = cursor.fetchone()

        if user:
            # Successful login
            return redirect(url_for('success'))
        else:
            # Failed login
            return redirect(url_for('failure'))

# Flask Route for Success
@app.route('/success')
def success():
    return "Login Successful!"

# Flask Route for Failure
@app.route('/failure')
def failure():
    return "Login Failed!"

if __name__ == '__main__':
    app.run(debug=True)
